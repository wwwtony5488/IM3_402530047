package Easter;


public class Easter {

	private Easter()
	{}
	public static String calculateEaster(int inputYear){
		int year=inputYear;
		int a = year % 19;
		int b = year %4;
		int c = year % 7;
		int k =	year/100;
		int p = (13+8*k)/25;
		int q = k/4;
		int M = (15-p+k-q)%30;
		int N = (4+k-q) % 7;
		int d = (19*a+M)%30;
		int e = (2*b+4*c+6*d+N)%7;
		int n;
		String output="";
		if((d+e)<10){
			n=d+e+22;
			output="In "+year+",Easter Sunday is:month=3 and day ="+n ;		
		}
		else{
			n=d+e-9;
			if(n==26){
				n=19;
			}
			if(n==25&&d==28&&e==6&&a>10)
				n=18;
			}
		
			output="In "+year+",Easter Sunday is:month=4 and day ="+n ;						
	
		return output;			
	}

}
